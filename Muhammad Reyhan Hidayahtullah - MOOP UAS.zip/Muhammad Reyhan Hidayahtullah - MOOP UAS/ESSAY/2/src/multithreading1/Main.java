/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multithreading1;

/**
 *
 * @author ACER
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Create thread that implements runnable
        for (int i = 0; i < 10; i++) {
            MyThreadRunnable thread1[] = new MyThreadRunnable[10];
            MyThreadClass thread2[] = new MyThreadClass[10];
        
            thread1[i] = new MyThreadRunnable(String.valueOf(i+1));
            thread2[i] = new MyThreadClass(String.valueOf(i+11));
            
            thread1[i].start();
            thread2[i].start();
        }
    }
    
}
