/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multithreading1;

/**
 *
 * @author ACER
 */
public class MyThreadClass extends Thread {
    private Thread thread;
    private String threadName;
    
    public MyThreadClass(String threadName) {
        this.threadName = threadName;
    }
    
    public void run() {
        funcB();
    }
    
    public void start() {
        if (thread == null) {
            thread = new Thread(this, threadName);
            thread.start();
        }
    }
    
    private void funcB() {
        System.out.print("Thread " + threadName + " ");
        System.out.println(2*2);
    }
}
