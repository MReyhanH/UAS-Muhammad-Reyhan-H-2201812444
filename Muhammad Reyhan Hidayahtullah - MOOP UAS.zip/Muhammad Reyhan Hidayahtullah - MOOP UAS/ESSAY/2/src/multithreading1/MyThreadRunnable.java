/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multithreading1;

/**
 *
 * @author ACER
 */
public class MyThreadRunnable implements Runnable {
    private Thread thread;
    private String threadName;
    
    public MyThreadRunnable(String threadName) {
        this.threadName = threadName;
    }
    
    @Override
    public void run() {
        funcA();
    }
    
    public void start() {
        if (thread == null) {
            thread = new Thread(this, threadName);
            thread.start();
        }
    }
    
    private void funcA() {
        System.out.print("Thread " + threadName + " : ");
        System.out.println(1+1);
    }
        
}
