package com.betastudio.battleofcastle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView castle1;
    private ImageView castle2;
    private ImageView heroes1;
    private ImageView heroes2;
    private ImageView victory1;
    private ImageView victory2;
    private Button btnBattle;
    private Button btnNext;

    private static final int MAX_TROOPS = 100000;
    private static final int MAX_HEROES = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        castle1 = findViewById(R.id.castle_1);
        castle2 = findViewById(R.id.castle_2);
        heroes1 = findViewById(R.id.heroes_1);
        heroes2 = findViewById(R.id.heroes_2);
        victory1 = findViewById(R.id.victory_1);
        victory2 = findViewById(R.id.victory_2);
        btnBattle = findViewById(R.id.btn_battle);
        btnNext = findViewById(R.id.btn_next);
        btnBattle.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_battle) {
            int battleNumber = 1;
                if (battleNumber == 1) {
                    battle1();
                    battleNumber++;
                }
                else {
                    battle2();
                    battleNumber--;
                }
        }
        else if (v.getId() == R.id.btn_next) {
                castle1.setImageResource(R.drawable.steel_castle);
                castle2.setImageResource(R.drawable.horse_castle);
                heroes1.setImageResource(R.drawable.infantry);
                heroes2.setImageResource(R.drawable.cavalry);
                victory1.setVisibility(View.INVISIBLE);
                victory2.setVisibility(View.INVISIBLE);
        }
    }

    private void battle1() {
        int troopsNumber1 = MAX_TROOPS;
        int troopsNumber2 = MAX_TROOPS;

        int troops1 = 1;
        int troops2 = 2;

        double boost1 = 0.4 * 5;
        double boost2 = 0.4 * 5;

        double troopsPower1 = troopsNumber1 + boost1 * troopsNumber1;
        double troopsPower2 = troopsNumber2 + boost2 * troopsNumber2;

        double kill1 = kill(troops1, troops2, troopsPower1);
        double kill2 = kill(troops2, troops1, troopsPower2);

        double survive1 = troopsNumber1 - kill2;
        double survive2 = troopsNumber2 - kill1;

        if (survive1 > survive2) {
            victory1.setVisibility(View.VISIBLE);
        }
        else if (survive1 < survive2) {
            victory2.setVisibility(View.VISIBLE);
        }

    }

    private void battle2() {
        int heroes1[] = {0,0,0,0,0};
        int heroes2[] = {1,1,2,2,2};

        int troopsNumber1[] = {10000,0,0};
        int troopsNumber2[] = {0,25000,75000};

        double boost1[] = new double[3];
        double boost2[] = new double[3];

        for(int i = 0; i <5; i++) {
            if (heroes1[i] == 0) {
                boost1[0] += 0.4;
            }
            else if (heroes1[i] == 1) {
                boost1[1] += 0.4;
            }
            else {
                boost1[2] += 0.4;
            }
            if (heroes2[i] == 0) {
                boost2[0] += 0.4;
            }
            else if (heroes2[i] == 1) {
                boost2[1] += 0.4;
            }
            else {
                boost2[2] += 0.4;
            }
        }

        double troopsPower1[] = new double[3];
        double troopsPower2[] = new double[3];

        for(int i = 0; i <3; i++) {
            troopsPower1[i] += boost1[i] * troopsNumber1[i];
            troopsPower2[i] += boost2[i] * troopsNumber2[i];
        }

        double kill1[][] = {{0,0,0},{0,0,0},{0,0,0}};
        double kill2[][] = {{0,0,0},{0,0,0},{0,0,0}};

        double survive1[] = new double[3];
        double survive2[] = new double[3];

        double totalSurvive1 = 0;
        double totalSurvive2 = 0;

        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                if (troopsNumber2[j] > 0) {
                    kill1[i][j] += kill(i, j, troopsPower1[i]);
                }
                if (troopsNumber1[j] > 0) {
                    kill2[i][j] += kill(i, j, troopsPower2[i]);
                }
                survive1[i] = troopsNumber1[i] - kill2[j][i];
                survive2[i] = troopsNumber2[i] - kill1[j][i];
                totalSurvive1 += survive1[i];
                totalSurvive2 += survive2[i];
            }
        }

        if (totalSurvive1 > totalSurvive2) {
            victory1.setVisibility(View.VISIBLE);
        }
        else if (totalSurvive1 < totalSurvive2) {
            victory2.setVisibility(View.VISIBLE);
        }

    }

    private double kill(int troops, int troops2, double troopsPower) {
        double killNumber = 0;
        switch (troops) {
            case 0 :
                if (troops2 == 0) killNumber = troopsPower;
                else if (troops2 == 1) killNumber = 0.1 * troopsPower;
                else killNumber = 0.4 * troopsPower;
                break;
            case 1 :
                if (troops2 == 0) killNumber = 0.4 * troopsPower;
                else if (troops2 == 1) killNumber = troopsPower;
                else killNumber = 0.1 * troopsPower;
                break;
            case 2 : {
                if (troops2 == 0) killNumber = 0.1 * troopsPower;
                else if (troops2 == 1) killNumber = 0.4 * troopsPower;
                else killNumber = troopsPower;
                break;
            }
        }
        return killNumber;
    }
}